package org.example;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Main {
    public static void main(String[] args) {

        LocalDate fechaSistema=LocalDate.now();
        LocalDate fechaManual=LocalDate.of(2023,8,8);
        LocalDate fechaNacimiento=LocalDate.of(2001,7,23);
        Long diferencia= ChronoUnit.YEARS.between(fechaNacimiento,fechaSistema);
        Boolean diferenciaentrefechas=fechaSistema.isBefore(fechaNacimiento);

        System.out.println(diferenciaentrefechas);
        System.out.println(diferencia);
        System.out.println(fechaSistema);
        System.out.println(fechaManual);
        System.out.println(fechaNacimiento);
    }
}